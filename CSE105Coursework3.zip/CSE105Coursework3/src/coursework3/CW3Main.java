
package coursework3;

/*READ ME: Use this class as your main class, and create your menu here
Your menu should then call the appropriate methods in the SkillSorter class
You need to complete the other classes, including the empty methods.
/*
*/
public class CW3Main {
    
    public static void main(String[] args){
        SkillSorter ss = new SkillSorter("save.txt");
        ss.display();
        /*String[] allSetSkills = new String[] {
            "CEA", "CDA", "CBA", "BAD", "BCE",
            "BBC", "ADA", "CAB", "DEE", "DCC",
            "DBC", "ECC", "CDC", "CCA", "BBC",
            "CBD", "EBC", "BCC", "DBD", "BBD",
            "AAD", "CED", "DCC", "ADE", "CCA",
            "CDA", "BAB", "AAB", "DBE", "BBB",
            "BCC", "ADC", "EED", "BBB", "BDC",
            "ACC", "DBC", "EAC", "DCC", "BEC",
            "CBB", "ECB", "ADC", "CBC", "CDD", 
            "ACC", "DEC", "DDC", "DAB", "EDD"
        };
        for (String setSkills:allSetSkills) {
            ss.addVolunteer(new Volunteer(setSkills));
        }*/
        for (int epoch=0;epoch<300;++epoch) {
            String s = "";
            for (int i=0;i<3;++i) {
                s += (char)('A' + (int) (Math.random() * 5));
            }
            ss.addVolunteer(new Volunteer(s));
        }
        ss.display();
        ss.exit("save.txt");
    }
    
    //Construct and run your menu here.
    //You MUST call methods in SkillSorter from your menu
    //and complete the methods in SkillSorter 
    //DO NOT write the methods, eg addVolunteer, in THIS class.
    //Call and use the ones in SkillSorter.
}
