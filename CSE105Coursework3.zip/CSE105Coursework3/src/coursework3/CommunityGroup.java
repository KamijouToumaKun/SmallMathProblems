//DO NOT CHANGE THIS PACKAGE
package coursework3;

import cw3interfaces.CommunityGroupInterface;
import java.util.ArrayList;


//DO NOT CHANGE THIS NAME
public class CommunityGroup implements CommunityGroupInterface {
    
    
    
 //COMPLETE THIS CLASS    
    private ArrayList<Volunteer> myVolunteers = new ArrayList<>();//contain volunteers
    
    
    public void clear() {
        myVolunteers.clear();
    }   
    
    public String getVolunteers() {//get skills of each volunteer
        String res = "";
        for (Volunteer v:myVolunteers) {
            res += v.getSkillSet() + " ";
        }
        //e.g. AAA ABC EEE 
        return res;
    }
    
    public void addVolunteer(Volunteer vol) {
        //set a new Volunteer of skillSet and add to myVolunteers
        myVolunteers.add(vol);
    }
    
    public boolean deleteVolunteer(String skillSet) {
        for (int i=0;i<myVolunteers.size();++i) {
            if (skillSet.equals(myVolunteers.get(i).getSkillSet())) {
                //if there's a volunteer whose skillSet fits
                myVolunteers.remove(i);
                return true;
            }
        }
        //otherwise: report something wrong
        return false;
    }
    
    public int[] getSkillsTotalNums() {
        int[] skillsTotalNums = new int[5];//initialize: all 0
        for (Volunteer v:myVolunteers) {
            String s = v.getSkillSet();//get each skill set
            for (int i=0;i<s.length();++i) {
                int index = (int)(s.charAt(i) - 'A');
                skillsTotalNums[index] ++;//the ith skill is counted to skillTotals[i]
            }
        }
        return skillsTotalNums;
    }
    
    public int getAllSkillsTotalNums() {
        int sum = 0;
        for (int num:getSkillsTotalNums()) {
            sum += num;
        }
        //e.g. Skill A: 13, Skill B: 20, Skill C: 23, Skill D: 5, Skill E: 41
        //return 13+20+23+5+41
        return sum;
    }
    
 //these public methods need to form the interface 
// DO NOT CHANGE ANY OF THESE METHOD NAMES, RETURN VALUES, OR ARGUMENTS   
    @Override
    public int howManyVolunteers(){
        //return the total number of volunteers in this community group
        //COMPLETE CODE HERE
        return myVolunteers.size();
    }
    
    @Override
    public String getSkillsTotals(){
        // return the total number of each skill in a String, example:
        //Skill A: 13, Skill B: 20, Skill C: 23, Skill D: 5, Skill E: 41
        //COMPLETE CODE HERE
        int[] skillsTotalNums = getSkillsTotalNums();
        String res = "";
        for (int i=0;i<5;++i) {
            res += "Skill " + (char)('A'+i) + ": " + skillsTotalNums[i] + ", ";
        }
        return res;
    }
            
    @Override
    public String toString() {
        return getSkillsTotals();
    }
    
    
    

}
