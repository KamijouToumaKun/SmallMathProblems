//DO NOT CHANGE THIS PACKAGE
package coursework3;

import cw3interfaces.SkillSorterInterface;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;




//DO NOT CHANGE THIS NAME
public class SkillSorter implements SkillSorterInterface{
    private ArrayList<CommunityGroup> myGroups = new ArrayList<>();
    
    //COMPLETE THIS CLASS
    SkillSorter(String filename) {
        for (int i=0;i<5;++i) {
            myGroups.add(new CommunityGroup());
        }
        load(filename);
    }
    
    public void load(String filename) {//Load Data
        try {
            File file = new File(filename);
            FileReader fr = new FileReader(file);
            BufferedReader in = new BufferedReader(fr);
            String line = null;

            for (int i=0;i<5;++i) {
                if ((line = in.readLine()) != null) {
                    String[] fragment = line.split(" ");
                    CommunityGroup cg = myGroups.get(i);
                    for (String setSkills:fragment) {
                        if (setSkills.length() == 3) {//skip " " or ""
                            cg.addVolunteer(new Volunteer(setSkills));
                        }
                    }
                }
            }
            fr.close();
            in.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void exit(String filename) {//Save and exit – Exit the program and save all group data to file 
        try {
            File file = new File(filename);
            FileWriter out = new FileWriter(file);
            for (int i=0;i<5;++i) {
                CommunityGroup cg = myGroups.get(i);
                out.write(cg.getVolunteers() + "\n");
            }
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.exit(0);
    }
    
    public void display() {//Display groups
        System.out.println(this);
    }
    
    @Override
    public String toString() {
        String res = "";
        for (int i=0;i<5;++i) {
            CommunityGroup cg = myGroups.get(i);
            res += "Group " + (i+1) + ":\n";//e.g. Group 1:
            res += cg.getSkillsTotals();//e.g. Skill A: 1, Skill B: 2, Skill C: 3, Skill D: 4, Skill E: 5
            res += "Total: " + cg.getAllSkillsTotalNums() + "\n";//e.g. Total: 15
            res += cg.getVolunteers() + "\n";//e.g. ABC BCD CDE DDD EEE 
        }
        return res;
    }
    
//these public methods need to form the interface 
// DO NOT CHANGE ANY OF THESE METHOD NAMES, RETURN VALUES, OR ARGUMENTS
    @Override
    public void addVolunteer(Volunteer vol){
        //add a volunteer to a Community Group USING YOUR SORTING ALGORITHM
        //COMPLETE CODE HERE
        
        String skillSet = vol.getSkillSet();
        int[] b = new int[3];
        for (int i=0;i<3;++i) {
            b[i] = (int)(skillSet.charAt(i) - 'A');
        }//get b = (t1, t2, t3)
        int minn = Integer.MAX_VALUE;
        int index = -1;
        for (int i=0;i<5;++i) {
            CommunityGroup cg = myGroups.get(i);
            if (cg.howManyVolunteers() < 500) {//up to 500 volunteers
                int[] skillsTotalNums = cg.getSkillsTotalNums();
                int sum = 0;
                for (int j=0;j<3;++j) {
                    sum += skillsTotalNums[b[j]];
                }
                if (sum < minn) {
                    minn = sum;//get min{a[t1] + a[t2] + a[t3]}
                    index = i;//get argmin{a[t1] + a[t2] + a[t3]}
                }
            }
        }
        if (index != -1) {
            myGroups.get(index).addVolunteer(vol);
        }
    }
    
    @Override
    public void moveVolunteer(String skillSet, CommunityGroup from, CommunityGroup to){
        //move a volunteer with this skillset (eg AAA, BCD) from one CommunityGroup to another
        //COMPLETE CODE HERE
        if (from.deleteVolunteer(skillSet)) {
            //there can be something wrong: there's no such volunteer in the CommunityGroup from
            to.addVolunteer(new Volunteer(skillSet));
            //only when he/she exists, can I move him/her to another CommunityGroup
        }
    }
    
    @Override
    public void deleteVolunteer(String skillSet, CommunityGroup from){
        //delete a volunteer with this skillset from this CommunityGroup
        //COMPLETE CODE HERE
        from.deleteVolunteer(skillSet);//delete a volunteer without checking his/her existing
    }
    
    @Override
    public void deleteAllVolunteers(){
        // delete all volunteers from all CommunityGroups
        //COMPLETE CODE HERE
        for (CommunityGroup cg:myGroups) {
            cg.clear();//clear each CommunityGroup
        }
    }

    @Override
    public ArrayList<CommunityGroup> getCommunityGroups(){
        //return an ArrayList of all this application's CommunityGroups
        return myGroups;
    }
    
    
}
